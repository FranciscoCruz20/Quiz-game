//Variaveis do jogador
//valores predefinidos para o começo do jogo
let player_jokers = 0
let fase_jogador = 0

//Esatdo do jogo , possível ser Dormindo ou Acordado
let game_state = "Dormindo"

//Checkpoints
let checkpoint = 0
let important_checkpoints = [1,2,3,4,5,7,10,15,17,20,33,38,39,46]

//Imagem das fases
let montanha_pico_image = ""

//Variaveis para o jogo da forca
let palavras_forca = ["Aduelas","Albói","Alvarozes","Arredouça","Arressaca","Bagocha","Binsuade","Besuga","Boca santa","Calafonas","Canica","Ceidiço","Clâme","Corisco mal amanhado","Correr roupa","Destarelado","Dia da pombinha","Dia de são vapor","Enrediadeira","Estás cegando","É um braçado","Fogo te abrase","Intenicar","Laparoso","Lombão","Moquenco","Palinho","Pega derête","Sopa de fueiro","Tirar uma chapa","Vá laré"]
let palavra_forca_selecionada = ""
//Lista de palavras usadas no jogo pelo jogador
let palavra_forca_usada = []

//Variaveis para as perguntas e respostas
//lista das respostas disponíveis, referentes aos botões
let respostas_disponiveis = []
let resposta_correta = ""
//Valor default
let jokers_usados_pergunta = 0
//Valor do timer
let contagem_segundos = 60;

//Outras variaveis
//defaults
let mapa_do_tesouro = 0
let forca_tentativas = 0

//Variaveis de niveis
//Lista perguntas de cada nível
let Nivel1Perguntas = []
let Nivel2Perguntas = []
let Nivel3Perguntas = []


//Classe das perguntas
class pergunta {
    constructor(perguntita, respostas, resposta_correta) {
        this.perguntita = perguntita;
        this.respostas = respostas;
        this.resposta_correta = resposta_correta;
    }
}

//Perguntas do jogo
//Perguntas de nível 1
Nivel1Perguntas.push(new pergunta("Quantas ilhas tem o arquipélago dos Açores?", ["9", "10", "8", "7"], "9"))
Nivel1Perguntas.push(new pergunta("Em que cidade está sedeada a Presidência do Governo Regional?", ["Ponta Delgada", "Horta", "Angra do Heroísmo", "Lagoa"], "Ponta Delgada"))
Nivel1Perguntas.push(new pergunta("Qual a  cidade açoriana classificada como Património Mundial em 1983?", ["Angra do Heroísmo", "Horta", "Ponta Delgada", "Lagoa"], "Angra do Heroísmo"))
Nivel1Perguntas.push(new pergunta("Qual a ilha mais conhecida pelas suas atividades baleeiras?", ["Pico", "Faial", "Graciosa", "Terceira"], "Pico"))
Nivel1Perguntas.push(new pergunta("Qual o nome da ave marinha que nidifica na região e que se caracteriza pelo seu grito noturno?", ["Cagarro", "Pardal", "Melro", "Priolo"], "Cagarro"))
Nivel1Perguntas.push(new pergunta("Se quiser comer um cozido confecionado a vapor num buraco escavado no solo, que ilha deve visitar? ", ["São Miguel", "Flores", "Graciosa", "Terceira"], "São Miguel"))
Nivel1Perguntas.push(new pergunta("De que ilha é característico um prato chamado Alcatra?", ["Pico", "São Jorge", "Faial", "Terceira"], "Terceira"))
Nivel1Perguntas.push(new pergunta("Qual a festa religiosa que se realiza em todas as ilhas?", ["Santo Cristo", "São João", "Espirito Santo", "Santo António"], "Espirito Santo"))
Nivel1Perguntas.push(new pergunta("Qual o cetáceo mais comum nos mares dos Açores?", ["Cachalote", "Golfinho Comum", "Baleia Azul", "Tubarão Martelo"], "Cachalote"))
Nivel1Perguntas.push(new pergunta("Em que ilha podemos subir ao ponto mais alto de Portugal?", ["São Miguel", "Pico", "Graciosa", "São Jorge"], "Pico"))
Nivel1Perguntas.push(new pergunta("Que nome se dá ao marisco univalve que se encontra agarrado à rocha marítima?", ["Lapa", "Amêijoa", "Berbigão", "Búzio"], "Lapa"))
Nivel1Perguntas.push(new pergunta("Quais as cores predominantes da bandeira dos Açores?", ["Azul + Branco", "Azul + Amarelo", "Amarelo + Branco", "Azul + Laranja"], "Azul + Branco"))
Nivel1Perguntas.push(new pergunta("Qual a ilha mais ocidental do arquipélago e consequentemente da Europa?", ["Corvo", "Santa Maria", "Graciosa", "Flores"], "Corvo"))
Nivel1Perguntas.push(new pergunta("Em que cidade se situam as instalações da Assembleia Legislativa Regional?", ["Angra do Heroísmo", "Ponta Delgada", "Lagoa", "Horta"], "Horta"))
Nivel1Perguntas.push(new pergunta("Que ilha é conhecida pelas suas fajãs?", ["São Jorge", "Pico", "Terceira", "Faial"], "São Jorge"))
//Perguntas de nível 2
Nivel2Perguntas.push(new pergunta("Qual a mais antiga vila açoriana?",["Velas","Calheta","Corvo","Vila do Porto"],"Vila do Porto"))
Nivel2Perguntas.push(new pergunta("Qual o nome da ilha onde se localiza o Centro de Controlo Aéreo do Atlântico?",["Santa Maria", "Terceira", "São Miguel", "Faial"],"Santa Maria"))
Nivel2Perguntas.push(new pergunta("Que ilha é conhecida pelas suas festividades taurinas, conhecidas por 'touradas à corda'?",["Terceira",  "São Jorge", "São Miguel", "Faial"],"Terceira"))
Nivel2Perguntas.push(new pergunta("Que ilha do arquipélago se localiza mais a norte?",["Corvo", "Flores", "Graciosa", "Pico"],"Corvo"))
Nivel2Perguntas.push(new pergunta("Qual a designação inicial mais conhecida para a ilha Terceira?",["Ilha de Jesus Cristo", "Ilha de Cristo", "Ilha da Luz", "Ilha do Mar"],"Ilha de Jesus Cristo"))
Nivel2Perguntas.push(new pergunta("Como se chama a zona balnear, onde se realiza o Festival de Verão denominado Maré de Agosto?",["Praia Pipas", "Praia Longa",  "Praia Formosa", "Praia da Areia"],"Praia Formosa"))
Nivel2Perguntas.push(new pergunta("Que doce característico da ilha  Terceira, tem o nome de uma rainha de Portugal?",["Dona Ana", "Dona Amélia", "Dona Maria", "Dona Isabel"],"Dona Amélia"))
Nivel2Perguntas.push(new pergunta("Como se chama a  espécie de ave endémica da ilha de São Miguel?",["Açor", "Milhafre", "Pombo Torcaz", "Priolo"],"Priolo"))
Nivel2Perguntas.push(new pergunta("Qual a designação do aeroporto em Ponta Delgada?",["Nordela", "João Paulo II", "Cristiano Ronaldo", "Pauleta"],"João Paulo II"))
Nivel2Perguntas.push(new pergunta("Em que ano foram inauguradas as “Portas do Mar” em Ponta Delgada?",["2008", "2007", "2009","2010"],"2008"))
Nivel2Perguntas.push(new pergunta("Qual o jornal açoriano mais antigo de Portugal?",["Correio dos Açores", "Açoriano Oriental", "Tribuna das Ilhas", "diário Insular"],"Açoriano Oriental"))
Nivel2Perguntas.push(new pergunta("Qual o açoriano que foi o primeiro presidente da República portuguesa?",["Teófilo Braga", "Manuel de Arriaga", "Bernardino Machado", "Sidónio Pais"],"Manuel de Arriaga"))
Nivel2Perguntas.push(new pergunta("Em que ano a RTP Açores realizou a sua primeira emissão?",["1974", "1975", "1977", "1978"],"1975"))
Nivel2Perguntas.push(new pergunta("Qual o presidente do primeiro governo regional dos Açores?",["Carlos César", "Mota Amaral", "Vasco Cordeiro", "Alberto João Jardim"],"Mota Amaral"))
Nivel2Perguntas.push(new pergunta("Quem é o autor da letra do Hino dos Açores",["Vitorino Nemésio", "Natália Correia", "João de Melo", "Fernando Pessoa"],"Natália Correia"))
//Perguntas de nível 3
Nivel3Perguntas.push(new pergunta("A quem é atribuído o povoamento inicial da ilha do Faial?" ,["Wilhelm van der Haegen", "Gonçalo Velho Cabral", "Joss van Hurtere", "Martin Behaim"],"Wilhelm van der Haegen"))
Nivel3Perguntas.push(new pergunta("Em que ano se deu a última erupção vulcânica da ilha do Faial?" ,["1955", "1956", "1957", "1958"],"1957"))
Nivel3Perguntas.push(new pergunta("Em 1501, Lages do Pico é elevada a vila e sede de concelho. Por quem?" ,["D.Manuel II", "D.João I", "D.Manuel I", "D.joão II"],"D.Manuel I"))
Nivel3Perguntas.push(new pergunta("Qual o nome vulgar da moeda fundida em 1829, na cidade de Angra do Heroísmo?" ,["Escudo", "Prata", "Maluco", "Vintém"],"Maluco"))
Nivel3Perguntas.push(new pergunta("Como se chama, na ilha de Santa Maria,  a baía que se caracteriza pelo formato de concha gigante?" ,["Baía de São Cristóvão", "Baía de São Lourenço", "Baía de São Miguel", "Baía dos Anjos"],"Baía de São Lourenço"))
Nivel3Perguntas.push(new pergunta("Em que freguesia, da ilha Terceira, se situa o Algar do Carvão?" ,["Porto Judeu", "Feteira","Altares", "Doze Ribeiras"],"Porto Judeu"))
Nivel3Perguntas.push(new pergunta("Que rei português foi exilado na ilha Terceira?" ,["D.Afonso II", "D.Afonso IV", "D.Afonso V", "D.Afonso VI"],"D.Afonso IV"))
Nivel3Perguntas.push(new pergunta("Qual a largura aproximada da ilha do Corvo?" ,["4 Km", "6 Km","8 Km","10 km"],"4 Km"))
Nivel3Perguntas.push(new pergunta("Na fase de expansão portuguesa, quem descobriu a ilha do Corvo?" ,["José Oliveira", "Diogo Morgado", "Manuel de Freitas", "Diogo de Teive"],"Diogo de Teive"))
Nivel3Perguntas.push(new pergunta("Quantas lagoas se encontram na zona central da ilha das Flores?" ,["Sete", "Quatro", "Duas", "Nove"],"Sete"))
Nivel3Perguntas.push(new pergunta("Quem apelidou a ilha do Faial de  ilha  Azul em 1924?" ,["Vitorino Nemésio",  "Manuel de Arriaga", "Raul Brandão", "João de  Melo"],"Raul Brandão"))
Nivel3Perguntas.push(new pergunta("Como era chamada a ilha de Santa Maria no século XIV?" ,["Ilha dos Lobos", "Ilha dos Cagarros", "Ilha do Sol", "Ilha do Sul"],"Ilha do Sol"))
Nivel3Perguntas.push(new pergunta("Na ilha Graciosa, em que ano Santa Cruz recebeu o titulo de Vila?" ,["1486", "1468", "1484", "1489"],"1486"))
Nivel3Perguntas.push(new pergunta("Qual o nome da formação geológica, de origem vulcânica, localizada no concelho da Madalena, na ilha do Pico?" ,["Gruta dos Fetos", "Gruta das Torres", "Ponta do Vulcão", "Jardim da Montanha"],"Gruta das Torres"))
Nivel3Perguntas.push(new pergunta("Em que ano se realizou a batalha da Salga?" ,["1580", "1581", "1590", "1591"],"1581"))



//Funções referentes ao ínicio do jogo(incluindo a passagem da tela inicial, para o jogo da forca e depois o jogo com perguntas:

//Começar o jogo mudando o estado do jogo
function comecar_jogo() {
    //Alteração do estado para "Acordado"
    game_state = "Acordado"
    //Esconder e mostrar elementos(div) na página
    hide_element("title")
    show_element("mapa_do_tesouro_image")
    document.getElementById("Inciar").style.visibility = 'hidden';
    document.getElementById("Inciar").style.display= 'none';
    update_phase()

}

//Atualizar fases do jogo
function update_phase(){
    //Verificação das fases onde o jogador se encontra
    if (fase_jogador === 0) {
        let html_body = document.getElementById("localização");
        montanha_pico_image = document.createElement("img");
        montanha_pico_image.src = "imagens/Montanha_postes.jpg";
        html_body.appendChild(montanha_pico_image);

        //Informação antes de inciar as perguntas da subida
        let info_label = document.getElementById("informacao_importante");
        info_label.innerText = "Irá começar a subida á montanha do pico!\nAntes da sua aventura, o nosso guia terá de avaliar as suas capacidades!\nAdivinhe a palavra açoreana!"

        //Primeiro jogo da forca para iniciar as perguntas
        let div_body = document.getElementById("forca_jogo");
        div_body.style="visibility: visible;"
        //Ir buscar umas das palavras da lista para adivinhar
        palavra_da_forca_random()
        let word = document.getElementById("palavra_forca");

        for (let i = 0; i < palavra_forca_selecionada.length; i++) {
            if (palavra_forca_selecionada[i] === " "){
                palavra_forca_usada.push(" ")
            }else{
                palavra_forca_usada.push("_")
            }
        }
        word.innerText = palavra_forca_usada.join(" ");

        //Contagem decrescente
        começar_timer_decresc()

    }
    //fase 1
    else if (fase_jogador === 1) {
        if (checkpoint === 2){
            montanha_pico_image.src= "imagens/Montanha_1.jpg";
            hide_element("jogo_cont")
            let info_label = document.getElementById("informacao_importante");
            info_label.innerText = "Descubra a seguinta palavra açoreana para proseguir a sua aventura!"

            //Jogo da forca para obter jokers
            let div_body = document.getElementById("forca_jogo");
            div_body.style="visibility: visible;"
            palavra_da_forca_random()
            show_element("forca_estrutura")
            show_element("countdown_timer")

            //Guardar palavra usada na forca
            palavra_forca_usada = []
            let word = document.getElementById("palavra_forca");
            for (let i = 0; i < palavra_forca_selecionada.length; i++) {
                if (palavra_forca_selecionada[i] === " "){
                    palavra_forca_usada.push(" ")
                }else{
                    palavra_forca_usada.push("_")
                }
            }
            word.innerText = palavra_forca_usada.join(" ");
            contagem_segundos = 50
            começar_timer_decresc()

        }else{
            montanha_pico_image.src= "imagens/Montanha_1.jpg";
            start_joker_questions()
        }

    }
    //fase 2
    else if (fase_jogador === 2) {
        if (checkpoint === 7){
            montanha_pico_image.src= "imagens/Montanha_2.jpg";
            hide_element("jogo_cont")
            let info_label = document.getElementById("informacao_importante");
            info_label.innerText = "Descubra a seguinta palavra açoreana para proseguir a sua aventura!"
            let div_body = document.getElementById("forca_jogo");
            div_body.style="visibility: visible;"
            palavra_da_forca_random()
            show_element("forca_estrutura")
            show_element("countdown_timer")

            palavra_forca_usada = []
            let word = document.getElementById("palavra_forca");
            for (let i = 0; i < palavra_forca_selecionada.length; i++) {
                if (palavra_forca_selecionada[i] === " "){
                    palavra_forca_usada.push(" ")
                }else{
                    palavra_forca_usada.push("_")
                }
            }
            word.innerText = palavra_forca_usada.join(" ");
            contagem_segundos = 50
            começar_timer_decresc()

        }else{
            montanha_pico_image.src= "imagens/Montanha_2.jpg";
            start_joker_questions()
        }

    }
    //fase 3
    else if (fase_jogador === 3) {
        if (checkpoint === 33){
            montanha_pico_image.src= "imagens/Montanha_3.jpg";
            hide_element("jogo_cont")
            let info_label = document.getElementById("informacao_importante");
            info_label.innerText = "Descubra a seguinta palavra açoreana para proseguir a sua aventura!"
            let div_body = document.getElementById("forca_jogo");
            div_body.style="visibility: visible;"
            palavra_da_forca_random()
            show_element("forca_estrutura")
            show_element("palavra_forca")
            show_element("countdown_timer")

            palavra_forca_usada = []
            let word = document.getElementById("palavra_forca");
            for (let i = 0; i < palavra_forca_selecionada.length; i++) {
                if (palavra_forca_selecionada[i] === " "){
                    palavra_forca_usada.push(" ")
                }else{
                    palavra_forca_usada.push("_")
                }
            }
            word.innerText = palavra_forca_usada.join(" ");
            contagem_segundos = 60
            começar_timer_decresc()

        }else{
            montanha_pico_image.src= "imagens/Montanha_3.jpg";
            start_joker_questions()
        }

    }
    document.getElementById("checkpoint").innerText = "Encontra-se no poste: " + checkpoint.toString() + "/46!"
}



//Funções referentes a jokers:

//Atualização do número de jokers, mostrando na tela o número dos mesmos
function atualizar_jokers(){
    document.getElementById("player_jokers").innerText = "Jokers disponíveis: "+ player_jokers
}

//Mostrar os jokers com imagens que o jogador tem
function draw_jokers(){
    let html_body = document.getElementById("jokers");
    html_body.innerText = ""
    //Mostrar imagens dos jokers disponíveis
    for (let i = 0; i < player_jokers; i++) {
        joker = document.createElement("img");

        joker.src = "imagens/jokerzito.png";

        joker.id ="jokerzito"+i.toString()
        html_body.appendChild(joker);

        carta_atual = document.getElementById('jokerzito'+i.toString())
        carta_atual.className = 'card_img';

        const top = 25 * i
        carta_atual.style.top = `${top}px`;

        carta_atual.style.zIndex = i;
    }
}

//função de pergunta bonus para dar jokers
function start_joker_questions(){
    show_element("countdown_timer_joker")
    show_element("player_jokers")
    show_element("jokers")
    show_element("play_joker")
    show_element("checkpoint")
    document.getElementById("respostabtn_1").disabled = false
    document.getElementById("respostabtn_2").disabled = false
    document.getElementById("respostabtn_3").disabled = false
    document.getElementById("respostabtn_4").disabled = false
    hide_element("forca_jogo")

    atualizar_jokers()
    draw_jokers()

    let outcome_phase = 1
    if (checkpoint >= 7 && checkpoint < 33){
        outcome_phase = 2
    } else if (checkpoint >= 33){
        outcome_phase = 3
    }
    mostrar_pergunta(outcome_phase)

    if(fase_jogador === 1){
        contagem_segundos_joker = 30
    }else if(fase_jogador === 2){
        contagem_segundos_joker = 40
    }else if(fase_jogador === 3){
        contagem_segundos_joker = 50
    }
    começar_timer_decresc_joker()
}

//função para usar um joekr nas respostas, onde uma das respostas erradas de foprma aleatória é eliminada e o jogador perde um dos jokers
function usar_joker(){
    if (player_jokers !== 0 && jokers_usados_pergunta !== 3){
        player_jokers -=1
        //remover iamgem da carta quando um joker é usado
        carta_atual = document.getElementById('jokerzito'+player_jokers.toString())
        carta_atual.remove()
        atualizar_jokers()
        jokers_usados_pergunta += 1
        let remove_wrong_answer = false

        //remover resposta caso seja errada
        while (remove_wrong_answer !== true){
            let index = Math.floor(Math.random() * respostas_disponiveis.length);

            if (respostas_disponiveis[index] !== resposta_correta){
                remove_wrong_answer = true
                //verifcar qual dos botões tem resposta errada e dar hide do mesmo
                if (document.getElementById("respostabtn_1").value === respostas_disponiveis[index]){
                    hide_element("respostabtn_1")
                    respostas_disponiveis.splice(index, 1)
                }

                else if (document.getElementById("respostabtn_2").value === respostas_disponiveis[index]){
                    hide_element("respostabtn_2")
                    respostas_disponiveis.splice(index, 1)
                }

                else if (document.getElementById("respostabtn_3").value === respostas_disponiveis[index]){
                    hide_element("respostabtn_3")
                    respostas_disponiveis.splice(index, 1)
                }

                else if (document.getElementById("respostabtn_4").value === respostas_disponiveis[index]){
                    hide_element("respostabtn_4")
                    respostas_disponiveis.splice(index, 1)
                }

            }
        }
    }
}



//Funções referentes ao jogo das perguntas:

//Mostrar as perguntas consuante a fase do jogo
function mostrar_pergunta(fase_perguntas){
    //Determinar o nível de perguntas consoante a fase do jogador
    let fase_id = fase_perguntas
    if (fase_perguntas === 1){
        fase_perguntas = Nivel1Perguntas
    }else if (fase_perguntas === 2){
        fase_perguntas = Nivel2Perguntas
    }else if(fase_perguntas === 3){
        fase_perguntas = Nivel3Perguntas
    }

    //Mostrar elementos(container do jogo e respetivos botões de resposta)
    show_element("jogo_cont")
    show_element("respostabtn_1")
    show_element("respostabtn_2")
    show_element("respostabtn_3")
    show_element("respostabtn_4")

    //verficar perfuntas disponíveis
    pergunta_selecionada = Math.floor(Math.random() * (fase_perguntas.length))
    respostas_disponiveis = fase_perguntas[pergunta_selecionada].respostas
    Pergunta = fase_perguntas[pergunta_selecionada]
    resposta_correta = Pergunta.resposta_correta

    if (fase_id === 1){
        Nivel1Perguntas.splice(pergunta_selecionada,1)
    }else if (fase_id === 2){
        Nivel2Perguntas.splice(pergunta_selecionada,1)
    }else if (fase_id === 3){
        Nivel3Perguntas.splice(pergunta_selecionada,1)
    }
        document.getElementById('joker_perguntita').innerHTML = Pergunta.perguntita
    let respostas = shuffleArray(Pergunta.respostas)
    for (let i = 1; i < 5; i++) {
        document.getElementById('respostabtn_'+ i).value = respostas[i-1]
    }
}

//verificar resposta selecionada
function verificar_resposta(respostas, id_btn){
    if (respostas === resposta_correta){
        //Parar contagem
        contagem_segundos_joker = "STOP"
        //Esconder elementos
        hide_element("countdown_timer_joker")
        hide_element("player_jokers")
        hide_element("jokers")
        hide_element("respostabtn_1")
        hide_element("respostabtn_2")
        hide_element("respostabtn_3")
        hide_element("respostabtn_4")
        hide_element("play_joker")
        hide_element("checkpoint")
        jokers_usados_pergunta = 0
        document.getElementById("joker_perguntita").innerText = "Resposta correta! Está a caminho do próximo poste..."
        avancar_casa()

    }else{
        //verfica como o jogador perde jokers e/ou desce casas
        let jogador_a_descer = false
        let descer_checkpoint = 0
        let descer_checkpoint_index = 1

        if (player_jokers >= 4){
            player_jokers -= 3
        }

        else if (player_jokers === 3){
            player_jokers -= 3
        }

        else if (player_jokers === 2){
            jogador_a_descer = true
            player_jokers -= 2

            for (let i = 0; i < important_checkpoints.length; i++) {
                if (important_checkpoints[i] < checkpoint){
                    descer_checkpoint = important_checkpoints[i]
                }
            }
            checkpoint = descer_checkpoint

        }else if (player_jokers === 1){
            jogador_a_descer = true
            player_jokers -= 1

            for (let i = 0; i < important_checkpoints.length; i++) {
                if (important_checkpoints[i] < checkpoint){
                    descer_checkpoint_index = i
                }
            }

            if (descer_checkpoint_index -1 <= 0){
                descer_checkpoint_index = 0
            }

            descer_checkpoint = important_checkpoints[descer_checkpoint_index]
            checkpoint = descer_checkpoint

        }else if (player_jokers === 0){

            if (checkpoint === 1){
                contagem_segundos_joker = 0

            } else {
                jogador_a_descer = true
                for (let i = 0; i < important_checkpoints.length; i++) {
                    if (important_checkpoints[i] < checkpoint){
                        descer_checkpoint_index = i
                    }
                }

                if (descer_checkpoint_index -2 <= 0){
                    descer_checkpoint_index = 0
                }
                descer_checkpoint = important_checkpoints[descer_checkpoint_index]
                checkpoint = descer_checkpoint

            }
        }

        if (jogador_a_descer === true){

            if (descer_checkpoint < 7){
                player_jokers = 1

            }else if (descer_checkpoint < 21){
                player_jokers = 2

            }else{
                player_jokers = 3
            }
        }

        //style de quando é selecionada uma resposta errada
        atualizar_jokers()
        draw_jokers()
        document.getElementById(id_btn).disabled = true
        document.getElementById(id_btn).style.background= "#d10000"
        document.getElementById(id_btn).style.color= "#ffffff"
    }
}


//Funções de estrutura e style/display de elementos na tela

//Esconder elemento na tela
function hide_element(element){
    document.getElementById(element).style="display: none; visibility: hidden;";
}

//Mostrar elemento na tela
function show_element(element){
    document.getElementById(element).style="visibility: visible;display inline";
}

//misturar arrays
function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array
}


//Funções referentes ao timer, tanto do jogo da forca/pergunats/jokers:

//função para fazer começar a contagem do tempo
function começar_timer_decresc(){
    //Alteração do estado de contagem
    if (contagem_segundos !== "STOP"){
        document.getElementById('countdown_timer').innerHTML = "Tempo Restante: "+ contagem_segundos +"!";
        contagem_segundos--;

        if (contagem_segundos < 0) {

            if (fase_jogador === 1 || fase_jogador === 0){
                document.getElementById("forca_jogo").style="display: none; visibility: hidden;";
                show_element("final")
                document.getElementById("final_label").innerText = "Você perdeu-se no caminho :(!"
                hide_element("mapa_do_tesouro")
                hide_element("localização")

            } else if (fase_jogador === 2 || fase_jogador === 3){
                contagem_segundos = "STOP"
                forca_tentativas += 1

                if (forca_tentativas !== 2){
                    update_phase()
                } else {
                    hide_element("palavra_forca")
                    hide_element("forca_estrutura")
                    avancar_casa()
                }

            }
        }

        else {
            setTimeout(começar_timer_decresc, 1000);
        }
    }
}

//função que começa a contagem do tempo para os jokers
function começar_timer_decresc_joker(){
    document.getElementById('countdown_timer_joker').innerHTML = "Tempo Restante: "+ contagem_segundos_joker +"!";

    if (contagem_segundos_joker !== "STOP"){
        contagem_segundos_joker--;

        if (contagem_segundos_joker < 0) {

            if (fase_jogador === 3 ||fase_jogador === 2 ||fase_jogador === 1 || fase_jogador === 0){
                hide_element("jogo_questoes_cont")
                hide_element("forca_jogo")
                hide_element("player_jokers")
                hide_element("jokers")
                hide_element("countdown_timer_joker")
                show_element("final")
                //Perder jogo
                document.getElementById("final_label").innerText = "Você perdeu-se no caminho :(!"
                hide_element("mapa_do_tesouro")
                hide_element("localização")
            }
        }

        else {
            setTimeout(começar_timer_decresc_joker, 1000);
        }
    }
}


//Funções referentes ao jogo da forca:

//função que dá uma palavra aleatoria para o jogo da forca
function palavra_da_forca_random(){
    //Buscar uma das das palavras da lista
    let index = Math.floor(Math.random() * palavras_forca.length)
    palavra_forca_selecionada = palavras_forca[index]
    palavras_forca.splice(index,1)
}

//função que verifica a letra escolhida na palavra selecionada para o jogo da forca
async function verificar_letra() {
    let user_inputted_letter = document.getElementById("forca_resposta").value;

    //Verificar letra na palavra selecionada
    for (let i = 0; i < palavra_forca_selecionada.length; i++) {
        if (palavra_forca_selecionada[i] === user_inputted_letter) {
            palavra_forca_usada[i] = user_inputted_letter
        }
    }

    let word = document.getElementById("palavra_forca");
    word.innerText = palavra_forca_usada.join(" ");
    document.getElementById('forca_resposta').value = ''
    document.getElementById('forca_resposta').focus()
    missing_chars = palavra_forca_usada.toString().split('_').length - 1

    if (missing_chars === 0) {
        contagem_segundos = "STOP"
        hide_element("forca_estrutura")
        hide_element("countdown_timer")
        //Atribuição de jokers dependendo da fase do jogador
        if (fase_jogador === 0) {
            fase_jogador = 1;
            player_jokers += 1; //default 1
            checkpoint += 1;

            document.getElementById('informacao_importante').innerHTML = 'Descobriu a palavra com sucesso, parabéns!'

            await sleep(4000);
            update_phase()

        } else if (fase_jogador === 1) {
            player_jokers += 4;
            checkpoint += 1;
            await sleep(4000);
            update_phase()

        } else if (fase_jogador === 2){
            forca_tentativas += 1
            player_jokers +=1
            await sleep(4000);

            if (forca_tentativas === 2){
                avancar_casa()
                await sleep(4000);

            }else{
                update_phase()
            }

        } else if (fase_jogador === 3){
            forca_tentativas += 1
            player_jokers +=1
            await sleep(4000);

            if (forca_tentativas === 2){
                avancar_casa()
                await sleep(4000);

            }else{
                update_phase()
            }
        }
    }
}



//Funções referentes a transições do jogo(recomeço/fim/inicio):

//função que recomeça o jogo
function recomecar_jogo(){
    location.reload();
}

//função que termina o jogo quando o jogador ganha
function terminar_jogo(){
    hide_element("jogo_cont")
    show_element("final")
    document.getElementById("final_label").innerText = "Muitos Parabéns!\nCom o seu desempenho chegou ao Topo do Pico!\n E encontrou todas as partes do mapa do tesouro!"
    montanha_pico_image.src= "imagens/Montanha_4.jpg";
    document.getElementById("mapa_do_tesouro_image").src="imagens/mapa 3.png"

}



//Função de avançar casa:

//função que faz o jogador passar pelos checkpoints
async function avancar_casa() {

    checkpoint += 1

    if (checkpoint === 47){
        terminar_jogo()

    } else {
        if (checkpoint === 33){
            forca_tentativas = 0
        }

        //Ataulização do mapa do tesouro
        if (mapa_do_tesouro === 0 && checkpoint === 7){
            
            mapa_do_tesouro = 1
            document.getElementById("mapa_do_tesouro_image").src="imagens/mapa_1.png"

        } else if (mapa_do_tesouro === 1 && checkpoint === 33){
            document.getElementById("mapa_do_tesouro_image").src="imagens/mapa 2.png"
        }

        if (!important_checkpoints.includes(checkpoint)) {

            if (forca_tentativas === 2){
                document.getElementById("informacao_importante").innerText = "Neste poste não existe nenhum desafio!\nCaminhando para o poste: " + checkpoint.toString() + "/46!"
                hide_element("palavra_forca")
            }

            document.getElementById("joker_perguntita").innerText = "Neste poste não existe nenhum desafio!\nCaminhando para o poste: " + checkpoint.toString() + "/46!"
            await sleep(3000);
            avancar_casa()

        } else {
            document.getElementById("checkpoint").innerText = "Encontra-se no poste: " + checkpoint.toString() + "/46!"

            if (checkpoint >= 7 && checkpoint < 33) {
                fase_jogador = 2

            } else if (checkpoint >= 33) {
                fase_jogador = 3

            } else {
                fase_jogador = 1
            }

            await sleep(3000);
            update_phase()
        }
    }

}



//Função de sleep:

//função de sleep para criar tempo de espera entre os jogos da forca e as perguntas, inicio/fim de jogo e mudança de fases de jogo
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}